// vite.config.js
import { defineConfig } from 'vite';

export default defineConfig({
    // Базовая конфигурация для разработки
    // Сборка библиотеки не требуется - публикуем исходный код
});