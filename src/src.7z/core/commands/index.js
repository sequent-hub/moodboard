// Экспорт всех команд
export { BaseCommand } from './BaseCommand.js';
export { CreateObjectCommand } from './CreateObjectCommand.js';
export { DeleteObjectCommand } from './DeleteObjectCommand.js';
export { MoveObjectCommand } from './MoveObjectCommand.js';
export { ResizeObjectCommand } from './ResizeObjectCommand.js';
