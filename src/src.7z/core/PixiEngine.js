import * as PIXI from 'pixi.js';

export class PixiEngine {
    constructor(container, eventBus, options) {
        this.container = container;
        this.eventBus = eventBus;
        this.options = options;
        this.objects = new Map();
    }

    async init() {
        this.app = new PIXI.Application({
            width: this.options.width,
            height: this.options.height,
            backgroundColor: this.options.backgroundColor,
            antialias: true
        });
        this.container.appendChild(this.app.view);
        globalThis.__PIXI_APP__ = this.app;
    }

    createObject(objectData) {
        // Создаем контейнер для объекта + рамки выделения
        const objectContainer = new PIXI.Container();
        objectContainer.name = `object-container-${objectData.id}`;
        
        // Создаем сам объект
        let pixiObject;
        switch (objectData.type) {
            case 'frame':
                pixiObject = this.createFrame(objectData);
                break;
            case 'simple-text':
            case 'text':
                pixiObject = this.createText(objectData);
                break;
            case 'shape':
                pixiObject = this.createShape(objectData);
                break;
            default:
                console.warn(`Unknown object type: ${objectData.type}`);
                pixiObject = this.createDefaultObject(objectData);
        }

        if (pixiObject) {
            // Настраиваем сам объект (в локальных координатах контейнера)
            // eventMode убираем - контейнер будет обрабатывать события
            pixiObject.eventMode = 'none'; // Отключаем интерактивность внутреннего объекта
            
            // Устанавливаем центр вращения в центр объекта
            if (pixiObject.anchor !== undefined) {
                // Для объектов с anchor (текст, спрайты)
                pixiObject.anchor.set(0.5, 0.5);
                // Позиционируем в центре контейнера
                pixiObject.x = (objectData.width || 100) / 2;
                pixiObject.y = (objectData.height || 100) / 2;
            } else if (pixiObject instanceof PIXI.Graphics) {
                // Для Graphics объектов устанавливаем pivot в центр
                const pivotX = (objectData.width || 100) / 2;
                const pivotY = (objectData.height || 100) / 2;
                pixiObject.pivot.set(pivotX, pivotY);
                
                // Позиционируем в центре контейнера
                pixiObject.x = pivotX;
                pixiObject.y = pivotY;
            }
            
            // Создаем рамку выделения (изначально невидимую)
            const selectionBorder = this.createSelectionBorder(objectData);
            selectionBorder.visible = false; // Скрыта по умолчанию
            
            // Добавляем объект и рамку в контейнер
            objectContainer.addChild(pixiObject);
            objectContainer.addChild(selectionBorder);
            
            // Позиционируем весь контейнер
            objectContainer.x = objectData.position.x;
            objectContainer.y = objectData.position.y;
            
            // Устанавливаем pivot контейнера в центр для корректного вращения
            const centerX = (objectData.width || 100) / 2;
            const centerY = (objectData.height || 100) / 2;
            objectContainer.pivot.set(centerX, centerY);
            objectContainer.x += centerX;
            objectContainer.y += centerY;
            
            // Применяем поворот если есть
            if (objectData.rotation) {
                objectContainer.rotation = objectData.rotation * Math.PI / 180;
            }
            
            // Настраиваем hit testing для контейнера
            objectContainer.eventMode = 'static';
            objectContainer.cursor = 'pointer';
            
            // Настраиваем hit area для контейнера
            const hitArea = new PIXI.Rectangle(
                -(objectData.width || 100) / 2, 
                -(objectData.height || 100) / 2, 
                objectData.width || 100, 
                objectData.height || 100
            );
            objectContainer.hitArea = hitArea;
            
            // Обработчик клика для контейнера
            objectContainer.on('pointerdown', (event) => {
                this.eventBus.emit('object:click', {
                    objectId: objectData.id,
                    position: { x: event.global.x, y: event.global.y }
                });
            });
            
            // Сохраняем ссылки
            objectContainer._mainObject = pixiObject;
            objectContainer._selectionBorder = selectionBorder;
            objectContainer.objectId = objectData.id;
            
            this.app.stage.addChild(objectContainer);
            this.objects.set(objectData.id, objectContainer);
        }
        
        return objectContainer;
    }

    createFrame(objectData) {
        const graphics = new PIXI.Graphics();
        
        const borderWidth = 2;
        const width = objectData.width || 100;
        const height = objectData.height || 100;
        
        // Рамка с учетом толщины границы
        graphics.lineStyle(borderWidth, objectData.borderColor || 0x333333, 1);
        graphics.beginFill(objectData.backgroundColor || 0xFFFFFF, objectData.backgroundAlpha || 0.1);
        
        // Рисуем с отступом на половину толщины границы
        const halfBorder = borderWidth / 2;
        graphics.drawRect(halfBorder, halfBorder, width - borderWidth, height - borderWidth);
        graphics.endFill();

        return graphics;
    }

    createText(objectData) {
        const textStyle = new PIXI.TextStyle({
            fontFamily: objectData.fontFamily || 'Arial',
            fontSize: objectData.fontSize || 16,
            fill: objectData.color || 0x000000,
            fontWeight: objectData.fontWeight || 'normal',
            fontStyle: objectData.fontStyle || 'normal'
        });

        const text = new PIXI.Text(objectData.content || 'Sample Text', textStyle);
        return text;
    }

    createShape(objectData) {
        const graphics = new PIXI.Graphics();
        
        // Цветной квадрат/круг
        graphics.beginFill(objectData.color || 0x3b82f6);
        
        if (objectData.shape === 'circle') {
            graphics.drawCircle(
                (objectData.width || 50) / 2, 
                (objectData.height || 50) / 2, 
                (objectData.width || 50) / 2
            );
        } else {
            graphics.drawRect(0, 0, objectData.width || 50, objectData.height || 50);
        }
        
        graphics.endFill();
        return graphics;
    }

    createDefaultObject(objectData) {
        // Заглушка для неизвестных типов
        const graphics = new PIXI.Graphics();
        graphics.beginFill(0xFF0000, 0.5);
        graphics.drawRect(0, 0, objectData.width || 100, objectData.height || 100);
        graphics.endFill();
        return graphics;
    }

    /**
     * Создает рамку выделения для объекта
     */
    createSelectionBorder(objectData) {
        const border = new PIXI.Graphics();
        
        // Рисуем рамку выделения
        border.lineStyle(1, 0x007ACC, 0.8);
        border.drawRect(0, 0, objectData.width || 100, objectData.height || 100);
        
        border.name = 'selection-border';
        border.zIndex = -1; // Рамка под объектом
        border.eventMode = 'none'; // Отключаем интерактивность рамки
        
        return border;
    }

    /**
     * Обновить рамку выделения с новым размером
     */
    recreateSelectionBorder(selectionBorder, size) {
        if (!selectionBorder) return;
        
        selectionBorder.clear();
        selectionBorder.lineStyle(1, 0x007ACC, 0.8);
        selectionBorder.drawRect(0, 0, size.width, size.height);
        selectionBorder.eventMode = 'none'; // Отключаем интерактивность рамки
    }

    /**
     * Показать рамку выделения для объекта
     */
    showSelectionBorder(objectId) {
        const objectContainer = this.objects.get(objectId);
        if (objectContainer && objectContainer._selectionBorder) {
            objectContainer._selectionBorder.visible = true;
        }
    }

    /**
     * Скрыть рамку выделения для объекта
     */
    hideSelectionBorder(objectId) {
        const objectContainer = this.objects.get(objectId);
        if (objectContainer && objectContainer._selectionBorder) {
            objectContainer._selectionBorder.visible = false;
        }
    }

    removeObject(objectId) {
        const pixiObject = this.objects.get(objectId);
        if (pixiObject) {
            this.app.stage.removeChild(pixiObject);
            this.objects.delete(objectId);
        }
    }

    /**
     * Обновить размер объекта
     */
    updateObjectSize(objectId, size, objectType = null) {
        const objectContainer = this.objects.get(objectId);
        if (!objectContainer) return;

        const mainObject = objectContainer._mainObject;
        const selectionBorder = objectContainer._selectionBorder;
        
        // Сохраняем позицию контейнера
        const position = { x: objectContainer.x, y: objectContainer.y };
        
        // Для Graphics объектов (рамки, фигуры) нужно пересоздать геометрию
        if (mainObject instanceof PIXI.Graphics) {
            this.recreateGraphicsObject(mainObject, size, position, objectType);
            // Обновляем рамку выделения
            this.recreateSelectionBorder(selectionBorder, size);
        } 
        // Для Text объектов изменяем размер шрифта
        else if (mainObject instanceof PIXI.Text) {
            this.updateTextObjectSize(mainObject, size);
            // Обновляем рамку выделения
            this.recreateSelectionBorder(selectionBorder, size);
        }
        
        // Обновляем hitArea контейнера
        objectContainer.hitArea = new PIXI.Rectangle(
            -size.width / 2, 
            -size.height / 2, 
            size.width, 
            size.height
        );
        
        // Обновляем pivot контейнера
        objectContainer.pivot.set(size.width / 2, size.height / 2);
    }

    /**
     * Пересоздать Graphics объект с новым размером
     */
    recreateGraphicsObject(pixiObject, size, position, objectType = null) {
        // Очищаем графику
        pixiObject.clear();
        

        
        // Определяем что рисовать по типу объекта
        if (objectType === 'frame') {
            // Рамка
            const borderWidth = 2;
            pixiObject.lineStyle(borderWidth, 0x333333, 1);
            pixiObject.beginFill(0xFFFFFF, 0.1);
            
            const halfBorder = borderWidth / 2;
            pixiObject.drawRect(halfBorder, halfBorder, size.width - borderWidth, size.height - borderWidth);
            pixiObject.endFill();
        } else if (objectType === 'shape') {
            // Фигура (заполненная)
            pixiObject.beginFill(0x007ACC, 0.8);
            pixiObject.drawRect(0, 0, size.width, size.height);
            pixiObject.endFill();
        } else {
            // Fallback - определяем по существующему содержимому (если тип не передан)
            console.warn(`⚠️ Тип объекта не определен, используем fallback логику`);
            
            // Если есть только контур без заливки - это рамка
            // Если есть заливка - это фигура
            const borderWidth = 2;
            pixiObject.lineStyle(borderWidth, 0x333333, 1);
            pixiObject.beginFill(0xFFFFFF, 0.1);
            
            const halfBorder = borderWidth / 2;
            pixiObject.drawRect(halfBorder, halfBorder, size.width - borderWidth, size.height - borderWidth);
            pixiObject.endFill();
        }
        
        // Устанавливаем pivot в центр (для правильного вращения)
        const pivotX = size.width / 2;
        const pivotY = size.height / 2;
        pixiObject.pivot.set(pivotX, pivotY);
        
        // Восстанавливаем позицию с компенсацией pivot
        pixiObject.x = position.x + pivotX;
        pixiObject.y = position.y + pivotY;
    }

    /**
     * Обновить размер текстового объекта
     */
    updateTextObjectSize(textObject, size) {
        // Для текстовых объектов адаптируем размер шрифта к новой высоте
        const fontSize = Math.max(12, Math.min(size.height / 2, size.width / 8));
        textObject.style.fontSize = fontSize;
        
        // Ограничиваем ширину текста
        textObject.style.wordWrap = true;
        textObject.style.wordWrapWidth = size.width - 10; // Небольшой отступ
    }

    /**
     * Обновить угол поворота объекта
     */
    updateObjectRotation(objectId, angleDegrees) {
        const pixiObject = this.objects.get(objectId);
        if (!pixiObject) return;

        // Конвертируем градусы в радианы
        const angleRadians = angleDegrees * Math.PI / 180;
        

        
        // Применяем поворот
        pixiObject.rotation = angleRadians;
    }

    /**
     * Поиск объекта в указанной позиции
     */
    hitTest(x, y) {
        // Hit test at coordinates
        
        // Получаем все объекты в позиции (PIXI автоматически учитывает трансформации)
        const point = new PIXI.Point(x, y);
        
        // Проходим по всем объектам от верхних к нижним
        for (let i = this.app.stage.children.length - 1; i >= 0; i--) {
            const child = this.app.stage.children[i];
            if (child.containsPoint && child.containsPoint(point)) {
                // Находим ID объекта
                for (const [objectId, pixiObject] of this.objects.entries()) {
                    if (pixiObject === child) {
                        return {
                            type: 'object',
                            object: objectId,
                            pixiObject: child
                        };
                    }
                }
            }
        }
        
        return { type: 'empty' };
    }

    destroy() {
        this.app.destroy(true);
    }
}