export class StateManager {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.state = {
            board: {},
            objects: [],
            selectedObjects: [],
            isDirty: false
        };
    }

    loadBoard(boardData) {
        this.state.board = boardData;
        this.state.objects = boardData.objects || [];
        this.eventBus.emit('board:loaded', boardData);
    }

    addObject(objectData) {
        this.state.objects.push(objectData);
        this.markDirty();
        this.eventBus.emit('object:created', objectData);
    }

    removeObject(objectId) {
        this.state.objects = this.state.objects.filter(obj => obj.id !== objectId);
        this.markDirty();
        this.eventBus.emit('object:deleted', objectId);
    }

    updateObjectPosition(objectId, position) {
        const object = this.state.objects.find(obj => obj.id === objectId);
        if (object) {
            object.position = position;
            this.markDirty();
            this.eventBus.emit('object:updated', { objectId, position });
        }
    }

    getObjects() {
        return [...this.state.objects];
    }

    serialize() {
        return {
            ...this.state.board, 
            objects: this.state.objects
        };
    }

    markDirty() {
        this.state.isDirty = true;
        
        // Уведомляем SaveManager о том, что состояние изменилось
        // Это нужно для Undo/Redo операций
        this.eventBus.emit('state:changed', {
            reason: 'state_marked_dirty',
            timestamp: Date.now()
        });
    }

    isDirty() {
        return this.state.isDirty;
    }
}