/**
 * Команда поворота объекта для системы Undo/Redo
 */
import { BaseCommand } from './BaseCommand.js';

export class RotateObjectCommand extends BaseCommand {
    constructor(objectId, oldAngle, newAngle, eventBus = null) {
        super('rotate', `Поворот объекта на ${(newAngle - oldAngle).toFixed(1)}°`);
        this.objectId = objectId;
        this.oldAngle = oldAngle;
        this.newAngle = newAngle;
        this.eventBus = eventBus;
    }

    setEventBus(eventBus) {
        this.eventBus = eventBus;
    }

    execute() {
        if (!this.eventBus) {
            console.error('❌ EventBus не установлен для RotateObjectCommand');
            return;
        }
        
        // Применяем новый угол поворота
        this.eventBus.emit('object:rotate', {
            objectId: this.objectId,
            angle: this.newAngle
        });

    }

    undo() {
        if (!this.eventBus) {
            console.error('❌ EventBus не установлен для RotateObjectCommand');
            return;
        }
        
        // Возвращаем старый угол поворота
        this.eventBus.emit('object:rotate', {
            objectId: this.objectId,
            angle: this.oldAngle
        });

    }

    redo() {
        this.execute();
    }

    getDescription() {
        const delta = this.newAngle - this.oldAngle;
        return `Поворот объекта на ${delta.toFixed(1)}°`;
    }
}
